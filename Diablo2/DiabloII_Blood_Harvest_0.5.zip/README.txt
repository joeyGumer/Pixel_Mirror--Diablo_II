Diablo II: Blood Harvest 0.5

Controls:
- Mouse Click on map: Move character
- Mouse Click on enemy: Attack enemy
- Mouse Click on item: Collect item

-R: Switch walk and run mode
-I: Show inventory

-Mouse Click on inventory item: Pick item
-Mouse Click on HUD item deck: Drop item on deck

-1: Use first item
-2: Use second item
-3: Use third item
-4: Use fourth item

-ESC: Open menu

How to win:
- Defeat the boss